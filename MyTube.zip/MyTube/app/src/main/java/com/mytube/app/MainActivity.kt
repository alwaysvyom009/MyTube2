package com.mytube.app

import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

private val Ink = Color(0xFF101114)
private val Panel = Color(0xFF1B1D22)
private val Accent = Color(0xFFFF3545)
private val Muted = Color(0xFF9A9DA6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("mytube", MODE_PRIVATE)
        setContent {
            var dark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
            MyTubeTheme(dark) {
                MyTubeApp(
                    dark = dark,
                    onThemeChange = { dark = it; prefs.edit().putBoolean("dark", it).apply() },
                    favorites = prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet(),
                    onFavorite = { id, saved ->
                        val updated = (prefs.getStringSet("favorites", emptySet()) ?: emptySet()).toMutableSet()
                        if (saved) updated.add(id) else updated.remove(id)
                        prefs.edit().putStringSet("favorites", updated).apply()
                    }
                )
            }
        }
    }
}

@Composable
private fun MyTubeTheme(dark: Boolean, content: @Composable () -> Unit) {
    val scheme = if (dark) darkColorScheme(primary = Accent, background = Ink, surface = Panel)
    else lightColorScheme(primary = Accent)
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
private fun MyTubeApp(
    dark: Boolean,
    onThemeChange: (Boolean) -> Unit,
    favorites: Set<String>,
    onFavorite: (String, Boolean) -> Unit
) {
    var tab by remember { mutableStateOf("Home") }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Video>>(emptyList()) }
    var selected by remember { mutableStateOf<Video?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val context = LocalContext.current
    val demo = remember {
        listOf(
            Video("dQw4w9WgXcQ", "Music and videos to get you started", "MyTube picks", "Demo recommendation"),
            Video("ysz5S6PUM-U", "Explore the world of video", "MyTube picks", "Demo recommendation"),
            Video("aqz-KE-bpKQ", "Nature and relaxing moments", "MyTube picks", "Demo recommendation")
        )
    }
    val visible = when (tab) {
        "Library" -> (demo + results).distinctBy { it.id }.filter { it.id in favorites }
        "Shorts" -> demo.reversed()
        else -> if (results.isNotEmpty()) results else demo
    }

    selected?.let { video ->
        PlayerScreen(video = video, isFavorite = video.id in favorites,
            onFavorite = { onFavorite(video.id, video.id !in favorites) }, onBack = { selected = null })
        return
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                listOf("Home", "Shorts", "Library", "Settings").forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item; error = "" },
                        icon = { Icon(when (item) { "Home" -> Icons.Default.Home; "Shorts" -> Icons.Default.PlayCircle; "Library" -> Icons.Default.Bookmarks; else -> Icons.Default.Settings }, null) },
                        label = { Text(item) }
                    )
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("My", color = MaterialTheme.colorScheme.onBackground, fontSize = 26.sp, fontWeight = FontWeight.Black)
                Text("Tube", color = Accent, fontSize = 26.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { tab = "Settings" }) { Icon(Icons.Default.Tune, "Settings") }
            }
            if (tab == "Settings") {
                SettingsScreen(dark, onThemeChange)
            } else {
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    placeholder = { Text("Search videos") }, singleLine = true,
                    trailingIcon = {
                        IconButton(enabled = query.isNotBlank() && !loading, onClick = {
                            loading = true; error = ""; results = emptyList()
                            (context as? ComponentActivity)?.lifecycleScope?.launch {
                                try { results = YouTubeApi.search(query, BuildConfig.YOUTUBE_API_KEY); if (results.isEmpty()) error = "No videos found." }
                                catch (e: Exception) { error = e.message ?: "Search failed. Check your API key and connection." }
                                finally { loading = false }
                            }
                        }) { Icon(Icons.Default.Search, "Search") }
                    }, shape = RoundedCornerShape(18.dp)
                )
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("For you", "Music", "Gaming", "Learning").forEach { label ->
                        Surface(color = if (label == "For you") Accent else Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.clickable { if (label != "For you") query = label }) {
                            Text(label, Modifier.padding(horizontal = 14.dp, vertical = 8.dp), color = Color.White, fontSize = 12.sp)
                        }
                    }
                }
                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Accent)
                if (error.isNotBlank()) Text(error, Modifier.padding(horizontal = 18.dp, vertical = 8.dp), color = Accent, fontSize = 13.sp)
                if (tab == "Library" && visible.isEmpty()) Text("Your saved videos will appear here.", Modifier.padding(24.dp), color = Muted)
                LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                    items(visible, key = { it.id }) { video ->
                        VideoRow(video, video.id in favorites, onOpen = { selected = video }, onFavorite = { onFavorite(video.id, video.id !in favorites) })
                    }
                }
            }
        }
    }
}

@Composable
private fun VideoRow(video: Video, favorite: Boolean, onOpen: () -> Unit, onFavorite: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(bottom = 18.dp)) {
        Box(Modifier.fillMaxWidth().height(196.dp).padding(horizontal = 12.dp).clip(RoundedCornerShape(16.dp)).background(Panel), contentAlignment = Alignment.Center) {
            AsyncImage(model = video.thumbnail, contentDescription = video.title, modifier = Modifier.fillMaxSize())
            Icon(Icons.Default.PlayCircleFilled, null, tint = Color.White, modifier = Modifier.size(58.dp))
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.Top) {
            Surface(color = Accent, shape = RoundedCornerShape(50), modifier = Modifier.size(38.dp)) { Box(contentAlignment = Alignment.Center) { Text("M", color = Color.White, fontWeight = FontWeight.Bold) } }
            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                Text(video.title, color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(video.channel, color = Muted, fontSize = 12.sp)
            }
            IconButton(onClick = onFavorite) { Icon(if (favorite) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, "Save", tint = if (favorite) Accent else Muted) }
        }
    }
}

@Composable
private fun PlayerScreen(video: Video, isFavorite: Boolean, onFavorite: () -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Ink)) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = Color.White) }
            Text("Now playing", color = Color.White, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onFavorite) { Icon(if (isFavorite) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, "Save", tint = if (isFavorite) Accent else Color.White) }
        }
        AndroidView(
            modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f),
            factory = { ctx -> WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                webChromeClient = WebChromeClient()
                webViewClient = WebViewClient()
                loadUrl("https://www.youtube-nocookie.com/embed/${video.id}?playsinline=1&rel=0")
            } }
        )
        Text(video.title, Modifier.padding(18.dp), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(video.channel, Modifier.padding(horizontal = 18.dp), color = Muted)
        if (video.description.isNotBlank()) Text(video.description, Modifier.padding(18.dp), color = Muted, fontSize = 13.sp, maxLines = 5, overflow = TextOverflow.Ellipsis)
        Text("Playback is provided by YouTube's embedded player.", Modifier.padding(18.dp), color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun SettingsScreen(dark: Boolean, onThemeChange: (Boolean) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(20.dp)) {
        Text("Settings", color = MaterialTheme.colorScheme.onBackground, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Dark appearance", color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.SemiBold)
                Text("Use a dark, low-glare interface", color = Muted, fontSize = 12.sp)
            }
            Switch(checked = dark, onCheckedChange = onThemeChange)
        }
        HorizontalDivider(Modifier.padding(vertical = 16.dp), color = Panel)
        Text("Search setup", color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.SemiBold)
        Text("Add YOUTUBE_API_KEY=your_key to the project's local.properties file to enable live video search with YouTube Data API v3.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        Text("Version 1.0.0", color = Muted, fontSize = 12.sp)
    }
}
