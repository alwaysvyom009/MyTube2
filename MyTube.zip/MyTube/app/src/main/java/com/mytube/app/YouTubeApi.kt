package com.mytube.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

object YouTubeApi {
    suspend fun search(query: String, apiKey: String): List<Video> = withContext(Dispatchers.IO) {
        require(apiKey.isNotBlank()) { "Add your YouTube Data API key in local.properties to enable search." }
        val encoded = URLEncoder.encode(query, "UTF-8")
        val endpoint = "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=20&q=$encoded&key=$apiKey"
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12000
            readTimeout = 12000
        }
        try {
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val root = JSONObject(body)
            val items = root.optJSONArray("items") ?: return@withContext emptyList()
            buildList {
                for (i in 0 until items.length()) {
                    val item = items.getJSONObject(i)
                    val id = item.optJSONObject("id")?.optString("videoId").orEmpty()
                    val snippet = item.optJSONObject("snippet") ?: continue
                    if (id.isNotBlank()) add(
                        Video(
                            id = id,
                            title = snippet.optString("title", "Untitled video"),
                            channel = snippet.optString("channelTitle", "YouTube creator"),
                            description = snippet.optString("description", "")
                        )
                    )
                }
            }
        } finally { connection.disconnect() }
    }
}
